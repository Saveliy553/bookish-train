
from aiogram import Bot, Dispatcher
from aiogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from aiogram.filters import Command, Text
import asyncio

API_TOKEN = "8180942100:AAFXDAa9MLMdjQc2_uf63yYXwK4QSbB9XHQ"
ADMIN_USERNAME = "@savadminov"

bot = Bot(token=API_TOKEN)
dp = Dispatcher()

user_data = {}
admin_message_map = {}

@dp.message(Command("start"))
async def start_handler(message: Message):
    await message.answer("Привет! Пришли ссылку на Telegram-аккаунт, который был заблокирован.")
    user_data[message.from_user.id] = {"step": "awaiting_link"}

@dp.message()
async def handle_message(message: Message):
    user_id = message.from_user.id

    if user_id not in user_data:
        await message.answer("Пожалуйста, начни с команды /start")
        return

    step = user_data[user_id]["step"]

    if step == "awaiting_link":
        user_data[user_id]["link"] = message.text
        user_data[user_id]["step"] = "awaiting_reason"
        await message.answer("Теперь напиши причину, по которой считаешь блокировку ошибочной.")
    elif step == "awaiting_reason":
        user_data[user_id]["reason"] = message.text

        link = user_data[user_id]["link"]
        reason = user_data[user_id]["reason"]
        full_name = message.from_user.full_name
        username = f"@{message.from_user.username}" if message.from_user.username else "Нет username"

        text = (
            f"🔔 Новая заявка на разблокировку:

"
            f"👤 Отправитель: {full_name} ({username})
"
            f"🔗 Ссылка на аккаунт: {link}
"
            f"📄 Причина: {reason}

"
            f"Выберите действие:"
        )

        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Одобрено", callback_data=f"approve:{user_id}"),
                InlineKeyboardButton(text="❌ Отказано", callback_data=f"reject:{user_id}")
            ]
        ])

        try:
            msg = await bot.send_message(chat_id=ADMIN_USERNAME, text=text, reply_markup=keyboard)
            admin_message_map[msg.message_id] = user_id
            await message.answer("Спасибо! Ваша заявка отправлена на рассмотрение.")
        except Exception as e:
            await message.answer("❌ Не удалось отправить админу. Убедитесь, что админ начал чат с ботом.")
            print(f"Ошибка при отправке админу: {e}")

        del user_data[user_id]

@dp.callback_query(Text(startswith="approve:"))
async def approve_callback(callback: CallbackQuery):
    user_id = int(callback.data.split(":")[1])
    await bot.send_message(user_id, "Ваша заявка была одобрена администратором ✅")
    await callback.answer("Вы одобрили заявку.")

@dp.callback_query(Text(startswith="reject:"))
async def reject_callback(callback: CallbackQuery):
    user_id = int(callback.data.split(":")[1])
    await bot.send_message(user_id, "Ваша заявка была отклонена администратором ❌")
    await callback.answer("Вы отклонили заявку.")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
